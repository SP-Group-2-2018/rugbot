export const firebaseConfig = {
  apiKey: "AIzaSyB81P8mwQ0vEX0epdQSQam7bcajW0Zo918",
  authDomain: "rugbot-38c57.firebaseapp.com",
  databaseURL: "https://rugbot-38c57.firebaseio.com",
  projectId: "rugbot-38c57",
  storageBucket: "rugbot-38c57.appspot.com",
  messagingSenderId: "1049949841310"
}
